namespace BookScraperTool.Models;

public class BookDetails
{
    public string? Title { get; set; }
    public string? Cost { get; set; }
    public string? StockInfo { get; set; }
    public string? DetailLink { get; set; }
}